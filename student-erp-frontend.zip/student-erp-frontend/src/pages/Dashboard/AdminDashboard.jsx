import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const navigate = useNavigate();

  // Get user role from localStorage, fallback to "Unknown"
  const role = localStorage.getItem("role") || "Unknown";

  // Logout handler: clear token & role, redirect to login page
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    navigate("/login");
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold mb-4">Welcome to Admin Dashboard!</h1>

      <p className="text-lg mb-6">
        Logged in as: <span className="font-semibold">{role}</span>
      </p>

      <button
        onClick={handleLogout}
        className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-lg font-semibold transition-colors"
      >
        Logout
      </button>
    </div>
  );
}

